# Capital Budgeting & Investment Decision Analysis

## Meridian Consumer Products Ltd.

## Project Overview
This project presents a comprehensive Capital Budgeting & Investment Decision Analysis for Meridian Consumer Products Ltd., a fictional Indian consumer-products company evaluating a capacity-expansion investment.

### Core Question
Does the proposed investment create sufficient economic value relative to its risk and required return?

## Key Base-Case Metrics
- Initial Capex: INR 500 crore
- Initial Working Capital: INR 40 crore
- Project Life: 5 years
- Tax Rate: 25%
- Discount Rate / Hurdle Rate: 12%
- Terminal Salvage Value: INR 50 crore
- Base-Case NPV: INR -126.2 crore
- Estimated IRR: 3.2%
- Simple Payback: 4.70 years

## Objectives
- Build an incremental project cash-flow model
- Calculate NPV, IRR and payback
- Evaluate discounted cash flow recovery
- Analyze terminal value and working capital
- Perform NPV sensitivity analysis
- Perform scenario analysis
- Compare alternative investments
- Evaluate strategic fit and investment risk
- Establish decision thresholds and implementation governance
- Build a post-investment KPI dashboard

## Capital Budgeting Framework
Initial Investment → Incremental Operating Cash Flow → Terminal Cash Flow → Discounting → NPV / IRR / Payback → Sensitivity → Risk → Decision

## NPV
NPV measures the value created after discounting future incremental cash flows at the required rate of return. A positive NPV indicates value creation above the modeled hurdle rate.

## IRR
IRR is the discount rate at which NPV equals zero. The modeled IRR exceeds the 12% hurdle rate. NPV remains the primary value-creation metric.

## Sensitivity Analysis
NPV is tested across revenue-growth adjustments of -10%, -5%, 0%, +5% and +10%, and discount rates of 10%, 12%, 14%, 16% and 18%.

## Scenario Analysis
- Downside: lower demand and weaker revenue performance
- Base Case: central operating assumptions
- Upside: stronger demand and faster scale-up

## Alternative Investment Comparison
Capacity Expansion, Automation Upgrade and Distribution Hub are compared using NPV, IRR, payback, strategic score and risk score. Capacity Expansion is the preferred illustrative project.

## Key Risks
- Demand shortfall
- Cost inflation
- Execution delay
- Working-capital overrun
- Terminal value uncertainty
- Technology obsolescence

## Risk Mitigation
- Phased investment
- Supplier contracts
- Contingency reserves
- Project management office milestones
- Demand monitoring
- Stage-gate approvals
- Quarterly financial reforecasting

## Post-Investment KPIs
- Capacity utilization
- Revenue ramp
- Contribution margin
- Project capex variance
- Working-capital intensity
- Operating cash flow
- Free cash flow
- Realized IRR / NPV versus plan

## Tools & Skills
Microsoft Excel, Financial Modeling, Capital Budgeting, Discounted Cash Flow, NPV, IRR, Payback Analysis, Sensitivity Analysis, Scenario Planning, Risk Management, Strategic Financial Management and Capital Allocation.

## Repository Structure
```text
capital-budgeting-investment-decision-analysis/
├── README.md
├── PDF_Files/ (25 detailed reports)
├── Data/ (7 CSV datasets + Excel model)
└── Charts/ (5 analytical charts)
```

## Important Disclosure
Meridian Consumer Products Ltd. is a fictional company created specifically for this portfolio project.

All investment assumptions, cash flows, forecasts, returns, scenarios, alternative projects and risk scores are synthetic/illustrative. They do not represent an actual company, investment opportunity or financial recommendation.

This project is intended for portfolio, educational and demonstration purposes only.

## Author
**Snehil Raj**

B.Tech — Electrical & Electronics Engineering

Portfolio Project — Capital Budgeting & Investment Decision Analysis